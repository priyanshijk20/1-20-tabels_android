package com.example.lenovo.timetable;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView timelistview;
    public void timestable(int h)
    {
        ArrayList<String> timetables=new ArrayList<>();
        for(int i=1;i<=10;i++)
        {
            timetables.add(Integer.toString(i* h));
        }
        ArrayAdapter<String> arradapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,timetables);
        timelistview.setAdapter(arradapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

     final SeekBar timetableseek =(SeekBar) findViewById(R.id.myseekBar);
        timelistview =(ListView) findViewById(R.id.myListview);

        timetableseek.setMax(20);
        timetableseek.setProgress(1);
       timetableseek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                int Timestable ;
                int min=1;

                if(i<min) {
                    Timestable = min;
              timetableseek.setProgress(min);
                }
                else
                    Timestable =i;

timestable(Timestable);


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        timestable(10);

    }
}

